
#ifndef CLIENT_H_INCLUDED
#define CLIENT_H_INCLUDED

void CustomSleep(int ms);
int main(int argc, char **argv);

#endif
